﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int a = new int();
        int b = new int();
        double wynik = new double();
        string[] tekst = new string[] { "Dobra robota!", "Oby tak dalej!", "Tak trzymaj!", "Świetnie Ci idzie!", "Super!", ":)"};
        public Form1()
        {
            InitializeComponent();
            label2.Text = "2+2=";
            a = 1;
            b = 1;
            wynik = 4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
                Random number = new Random();
            if (textBox1.Text == wynik.ToString())
            {
                int temp = new int();
                temp = number.Next(0,5);
                MessageBox.Show(tekst[temp]);
                double x = new double();
                double y = new double();

                switch (b)
                {
                    case 1:
                        x = number.Next(1, 10);
                        y = number.Next(1, 10);
                        break;
                    case 2:
                        x = number.Next(1, 100);
                        y = number.Next(1, 100);
                        break;
                    case 3:
                        x = number.Next(1, 1000);
                        x /= 100;
                        y = number.Next(1, 1000);
                        y /= 100;
                        break;
                }
                x.ToString();
                y.ToString();

                switch (a)
                {
                    case 1:
                        label2.Text = x + "+" + y + "=";
                        wynik = x + y;
                        break;
                    case 2:
                        if (x < y)
                        {
                            wynik = x;
                            x = y;
                            y = x;
                        }
                        label2.Text = x + "-" + y + "=";
                        wynik = x - y;
                        break;
                    case 3:
                        label2.Text = x + "*" + y + "=";
                        wynik = x * y;
                        break;
                    case 4:
                        wynik = x;
                        x *= y;
                        label2.Text = x + "/" + y + "=";
                        break;
                }
            }
            else
                MessageBox.Show("Spróbuj jeszcze raz");
        }

        private void dodawanieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            a = 1;
            dodawanieToolStripMenuItem.Checked = true;
            odejmowanieToolStripMenuItem.Checked = false;
            mnożenieToolStripMenuItem.Checked = false;
            dzielenieToolStripMenuItem.Checked = false;
        }

        private void odejmowanieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            a = 2;
            dodawanieToolStripMenuItem.Checked = false;
            odejmowanieToolStripMenuItem.Checked = true;
            mnożenieToolStripMenuItem.Checked = false;
            dzielenieToolStripMenuItem.Checked = false;
        }

        private void mnożenieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            a = 3;
            dodawanieToolStripMenuItem.Checked = false;
            odejmowanieToolStripMenuItem.Checked = false;
            mnożenieToolStripMenuItem.Checked = true;
            dzielenieToolStripMenuItem.Checked = false;
        }

        private void dzielenieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            a = 4;
            dodawanieToolStripMenuItem.Checked = false;
            odejmowanieToolStripMenuItem.Checked = false;
            mnożenieToolStripMenuItem.Checked = false;
            dzielenieToolStripMenuItem.Checked = true;
        }

        private void łatwyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            b = 1;
            łatwyToolStripMenuItem.Checked = true;
            średniToolStripMenuItem.Checked = false;
            trudnyToolStripMenuItem.Checked = false;
        }

        private void średniToolStripMenuItem_Click(object sender, EventArgs e)
        {
            b = 2;
            łatwyToolStripMenuItem.Checked = false;
            średniToolStripMenuItem.Checked = true;
            trudnyToolStripMenuItem.Checked = false;
        }

        private void trudnyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            b = 3;
            łatwyToolStripMenuItem.Checked = false;
            średniToolStripMenuItem.Checked = false;
            trudnyToolStripMenuItem.Checked = true;
        }
    }
}
